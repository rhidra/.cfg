#ifndef _CONFIG_H
#define _CONFIG_H

#define CLE_COIFFEUR 10
#define CLE_CLIENT 11
#define CLE_MUTEX 12

#define MAX_CLIENTS 5

#endif
